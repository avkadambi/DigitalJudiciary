## What this changes

## Which figures move, if any
<!-- If a trace, corpus or digest changes, say which and paste the new RESULT lines. "None" is a fine answer. -->

## Checklist
- [ ] `ruff check .` passes
- [ ] `python -m pytest tests -q` passes
- [ ] If a check was added: its mutant is in the pack's mutation matrix and dies
- [ ] If a generator changed: corpora rebuilt with `--rebuild` and `simulation/MANIFEST.json` digests updated
- [ ] Release notes / CHANGELOG entry added
