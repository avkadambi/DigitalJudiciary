---
name: Corpus or constitution finding
about: A provision, case, scenario or expectation you believe is wrong
labels: corpus
---

**Pack and identifier** (e.g. `meridian-corpus`, `MF-PAY-004`, case `MF-3412`):

**What you believe is wrong, and why** (cite the instrument if a regulation is involved):

**Proposed treatment**: a draft amendment filed against the provision (preferred) / a generator change / a documentation fix
