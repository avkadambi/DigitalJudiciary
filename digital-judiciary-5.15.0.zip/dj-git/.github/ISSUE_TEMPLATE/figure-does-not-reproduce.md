---
name: A figure does not reproduce
about: A number in the papers, README or REPRODUCE.md differs from what the package produces
labels: reproduction
---

**Which figure** (file, section, the number as printed):

**What the package produced** (paste the `RESULT` or report line):

**Command and environment** (`python3 --version`, OS, the exact command, `VERSION`):

**Manifest check**: does `python -m pytest tests -q -k digest` pass?
